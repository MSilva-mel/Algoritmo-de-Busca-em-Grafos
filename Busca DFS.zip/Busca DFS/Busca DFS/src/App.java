public class App {
    public static void main(String[] args) throws Exception {
        Grafo grafo = new Grafo(12);

        // Adicionando arestas
        grafo.adicionarConexao(0, 1);
        grafo.adicionarConexao(0, 5);
        grafo.adicionarConexao(0, 6);
        grafo.adicionarConexao(1, 3);
        grafo.adicionarConexao(1, 4);
        grafo.adicionarConexao(1, 5);
        grafo.adicionarConexao(4, 6);
        grafo.adicionarConexao(4, 2);
        grafo.adicionarConexao(6, 7);
        grafo.adicionarConexao(7, 9);
        grafo.adicionarConexao(9, 2);
        grafo.adicionarConexao(2, 11);
        grafo.adicionarConexao(4, 8);
        grafo.adicionarConexao(8, 10);

        // Criando a classe DFS e realizando a busca a partir do vértice 0
        DFS dfs = new DFS(grafo);
        dfs.dfs(0);

        System.out.println("\n");

        grafo.mostrarAdjacencia(0);

    }
}
