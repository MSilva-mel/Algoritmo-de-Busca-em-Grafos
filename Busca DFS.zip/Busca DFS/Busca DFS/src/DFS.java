public class DFS {

    Grafo gra;

    public DFS(Grafo gra) {
        this.gra = gra;
    }



    private void dfsRecursivo(int computador, boolean[] visitados) {
        visitados[computador] = true;  
        System.out.print(computador + " ");  

        
        for (int adj : gra.adjList.get(computador)) {
            if (!visitados[adj]) {
                dfsRecursivo(adj, visitados);
            }
        }
    }

    public void dfs(int computador) {
        boolean[] visitados = new boolean[gra.getComputadores()];  
        System.out.println("Busca em Profundidade (DFS) a partir do computador " + computador + ":");
        dfsRecursivo(computador, visitados);  
    }
}
