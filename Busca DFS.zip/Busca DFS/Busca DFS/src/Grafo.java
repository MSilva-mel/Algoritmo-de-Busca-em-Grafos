import java.util.ArrayList;
import java.util.List;

class Grafo {
    private int computadores;

    List<List<Integer>> adjList;
    
    public int getComputadores() {
        return computadores;
    }


    public void setComputadores(int computadores) {
        this.computadores = computadores;
    }

    public List<List<Integer>> getAdjList() {
        return adjList;
    }


    public void setAdjList(List<List<Integer>> adjList) {
        this.adjList = adjList;
    }

    


    public Grafo(int computadores) {
        this.computadores = computadores;
        adjList = new ArrayList<>();
        
        for (int i = 0; i < computadores; i++) {
            adjList.add(new ArrayList<>());
        }
    }

    
    public void adicionarConexao(int v1, int v2) {
            adjList.get(v1).add(v2);

    }

    public void mostrarAdjacencia(int computador) {
        if (computador < 0 || computador >= computadores) {
            System.out.println("Computador inválido.");
        } else {
            System.out.println("Computadores conectados ao computador " + computador + ": " + adjList.get(computador));
        }
    }


   
}
